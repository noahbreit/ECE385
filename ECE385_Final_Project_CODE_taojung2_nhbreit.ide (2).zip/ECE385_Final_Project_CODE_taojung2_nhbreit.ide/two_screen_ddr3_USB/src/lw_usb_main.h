#ifndef LW_USB_MAIN_H
#define LW_USB_MAIN_H

#include "lw_usb/GenericTypeDefs.h"

void copy_usb_code();
void usb_keyboard_fetch();
//BYTE * GetKeyboardData();

#endif
