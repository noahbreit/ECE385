1. Import this file into Vitis.
2. Attactch two PMOD-OLED displays to the two PMOD ports
3. Attach a usb keyboard
4. Build project and run the code